#!/bin/bash
# test 3
test $(./parens <<< "") = no 
