#include <stdio.h>
// hello world in C
int main() {
printf("hello, world!\n");
return 0;
}

