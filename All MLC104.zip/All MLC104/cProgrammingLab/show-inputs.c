#include <stdio.h>
// hello world in C
int main(int argc,char*argv[]) {
printf("%s\n",argv[0]);
return 0;
}

