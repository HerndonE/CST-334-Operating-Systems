#!/bin/bash
# problem 1
./hash-test.sh 1 '51ffcd517a811af07cbc925a876338af  -'
