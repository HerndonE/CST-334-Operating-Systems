#!/bin/bash
# code compiles
rm -f msh2
gcc -o msh2 msh2.c
