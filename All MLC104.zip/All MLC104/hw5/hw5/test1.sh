#!/bin/bash
# code compiles
rm -f msh4
gcc -o msh4 msh4.c
