#!/bin/bash
#  code compiles
rm -f bindec
gcc -o bindec bindec.c -lm && chmod +x bindec
