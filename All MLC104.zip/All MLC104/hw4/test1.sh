#!/bin/bash
# code compiles

rm -f msh3
gcc -o msh3 msh3.c
