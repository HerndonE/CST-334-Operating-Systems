#!/bin/bash
# code compiles
rm -f msh1
gcc -o msh1 msh1.c
