// symbol table operations
int lookup(char s[]);
int insert(char s[], int tok);
int token(int p);
char *tok_str(int p);
void symtable_to_string();
