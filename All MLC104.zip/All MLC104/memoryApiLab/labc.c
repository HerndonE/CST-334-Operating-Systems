#include <stdio.h>
#include <stdlib.h>

// starter code for Problems 4-8 of OSTEP, chapter 14
int main() {
   int *x;
   int *data;
   
   data = (int *)malloc(100 * sizeof(int));
   data[0]= 100;   
   printf("data[1] = %d\n", data[0]);

   x = (int *)malloc(10 * sizeof(int));
   x[0] = 1;
   x[1] = 2;
   printf("x[1] = %d\n", x[1]);

   return 0;
}

